package com.example.appprova;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etPassos;
    private RadioGroup rgTamanhoPasso;
    private CheckBox cbCorrida;
    private TextView tvResultado;
    private Button btnCalcular, btnIrParaIMC;
    private RadioButton rb_curto, rb_medio, rb_longo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPassos = findViewById(R.id.et_passos);
        rgTamanhoPasso = findViewById(R.id.rg_tamanho_passo);
        cbCorrida = findViewById(R.id.cb_corrida);
        tvResultado = findViewById(R.id.tv_resultado);
        btnCalcular = findViewById(R.id.btn_calcular);
        btnIrParaIMC = findViewById(R.id.btn_ir_para_imc);
        rb_curto = findViewById(R.id.rb_curto);
        rb_medio = findViewById(R.id.rb_medio);
        rb_longo = findViewById(R.id.rb_longo);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularDistancia();
            }
        });

        btnIrParaIMC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, IMCActivity.class);
                startActivity(intent);
            }
        });
    }

    private void calcularDistancia() {
        String passosText = etPassos.getText().toString();
        if (passosText.isEmpty()) {
            tvResultado.setText("Por favor, insira a quantidade de passos.");
            return;
        }
        int passos = Integer.parseInt(passosText);
        double tamanhoPasso = 0;
        int op = rgTamanhoPasso.getCheckedRadioButtonId();
       // tvResultado.setText("Selecione um tamanho de passo."+op);
        switch (op) {
            case 2131231087:
                tamanhoPasso = 0.5;
                break;
            case 2131231089:
                tamanhoPasso = 0.7;
                break;
            case 2131231088:
                tamanhoPasso = 1.0;
                break;
            default:
                tvResultado.setText("Selecione um tamanho de passo.");
                return;
        }

        double distancia = passos * tamanhoPasso;

        // Se estava correndo, aumentar a distância em 10%
        if (cbCorrida.isChecked()) {
            distancia *= 1.1;
        }

        tvResultado.setText("Distância Percorrida: " + String.format("%.2f", distancia) + " metros");
    }
}