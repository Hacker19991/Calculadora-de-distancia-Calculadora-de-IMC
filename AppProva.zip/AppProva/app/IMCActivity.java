package com.example.appprova;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class IMCActivity extends AppCompatActivity {

    private EditText etPeso, etAltura;
    private TextView tvResultadoIMC;
    private Button btnCalcularIMC, btnVoltarDistancia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        etPeso = findViewById(R.id.et_peso);
        etAltura = findViewById(R.id.et_altura);
        tvResultadoIMC = findViewById(R.id.tv_resultado_imc);
        btnCalcularIMC = findViewById(R.id.btn_calcular_imc);
        btnVoltarDistancia = findViewById(R.id.btn_voltar_distancia);

        btnCalcularIMC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });

        btnVoltarDistancia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularIMC() {
        String pesoText = etPeso.getText().toString();
        String alturaText = etAltura.getText().toString();

        if (pesoText.isEmpty() || alturaText.isEmpty()) {
            tvResultadoIMC.setText("Por favor, insira seu peso e altura.");
            return;
        }

        double peso = Double.parseDouble(pesoText);
        double altura = Double.parseDouble(alturaText);

        double imc = peso / (altura * altura);

        tvResultadoIMC.setText("Seu IMC é: " + String.format("%.2f", imc));
    }
}